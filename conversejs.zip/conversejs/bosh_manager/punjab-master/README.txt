GENERAL INFORMATION

PunJab is a HTTP jabber client interface. It is a BOSH connection manager that
allows persistent client connections to a XMPP server.

INSTALL

See INSTALL.txt for setup and installation instructions.

CONTRIBUTORS

Jack Moffitt xmpp:jackm@jabber.org

Garret Heaton <powdahound@gmail.com>

Zewt (https://github.com/zewt)

COPYRIGHT AND WARRANTY

Copyright (C) 2001-2013 Christopher Zorn , tofu@thetofu.com

The code in this distribution is made available under the MIT License.

See LICENSE.txt for more details.

