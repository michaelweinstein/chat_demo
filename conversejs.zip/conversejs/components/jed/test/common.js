expect = require('../node_modules/expect.js/expect');
Jed = require('../jed');
