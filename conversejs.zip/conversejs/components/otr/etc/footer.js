
  return {
      OTR: this.OTR
    , DSA: this.DSA
  }

}))