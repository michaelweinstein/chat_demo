module.exports = {
    DSA: require('./lib/dsa.js')
  , OTR: require('./lib/otr.js')
}