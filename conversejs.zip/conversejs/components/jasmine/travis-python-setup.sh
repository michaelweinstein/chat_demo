add-apt-repository -y ppa:fkrull/deadsnakes
apt-get update
apt-get install python2.6 python2.6-dev python3.3 python3.3-dev pypy pypy-dev
pip install tox
